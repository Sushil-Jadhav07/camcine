// src/sections/HomePage.tsx  — TMDB-powered version
// Replace mock contentService calls with tmdbService calls

import { useEffect, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Play, Info, Star, Clock, ChevronRight, Plus } from 'lucide-react';
import { useQuery } from '@tanstack/react-query';
import { tmdbService } from '@/services/tmdbService';
import { ContentCard } from '@/components/cards/ContentCard';
import { usePlayerStore } from '@/store';
import type { Content } from '@/types';

gsap.registerPlugin(ScrollTrigger);

const GENRES = ['All', 'Action', 'Drama', 'Thriller', 'Comedy', 'Horror', 'Sci-Fi', 'Romance', 'Animation', 'Documentary'];

export function HomePage() {
  const heroRef = useRef<HTMLDivElement>(null);
  const [currentSlide, setCurrentSlide] = useState(0);
  const [activeGenre, setActiveGenre] = useState('All');
  const { openPlayer } = usePlayerStore();

  // ── TMDB queries ────────────────────────────────────────
  const { data: trending = [] } = useQuery({
    queryKey: ['tmdb-trending'],
    queryFn: tmdbService.getTrending,
    staleTime: 5 * 60 * 1000,
  });

  const { data: popularMovies = [] } = useQuery({
    queryKey: ['tmdb-popular-movies'],
    queryFn: tmdbService.getPopularMovies,
    staleTime: 5 * 60 * 1000,
  });

  const { data: popularSeries = [] } = useQuery({
    queryKey: ['tmdb-popular-series'],
    queryFn: tmdbService.getPopularSeries,
    staleTime: 5 * 60 * 1000,
  });

  const { data: featured = [] } = useQuery({
    queryKey: ['tmdb-featured'],
    queryFn: tmdbService.getFeatured,
    staleTime: 5 * 60 * 1000,
  });

  const { data: nowPlaying = [] } = useQuery({
    queryKey: ['tmdb-now-playing'],
    queryFn: tmdbService.getNowPlaying,
    staleTime: 5 * 60 * 1000,
  });

  // ── Hero content (cycles through featured) ───────────────
  const heroSlides = featured.length > 0 ? featured : trending.slice(0, 3);
  const heroContent: Content = (heroSlides[currentSlide] ?? {
    id: 'default-1',
    title: 'Welcome to Camcine',
    description: 'Stream the best movies, shows, live news and songs. Your premium entertainment destination.',
    type: 'movie', status: 'free',
    poster: 'https://images.unsplash.com/photo-1536440136628-849c177e76a1?w=500&h=750&fit=crop',
    backdrop: 'https://images.unsplash.com/photo-1514306191717-45224512c2d0?w=1920&h=1080&fit=crop',
    releaseYear: 2026, genres: ['Drama'], rating: 'U/A', duration: 7200,
    languages: ['EN'], region: 'Hollywood', mood: [], cast: [], crew: [], tags: [],
    isTrending: true, isFeatured: true, viewCount: 0, likes: 0,
  }) as Content;

  // ── GSAP ──────────────────────────────────────────────────
  useEffect(() => {
    const ctx = gsap.context(() => {
      const tl = gsap.timeline();
      tl.fromTo('.hero-backdrop', { opacity: 0, scale: 1.08 }, { opacity: 1, scale: 1, duration: 1.4, ease: 'power3.out' })
        .fromTo('.hero-glow', { opacity: 0, scale: 0.8 }, { opacity: 1, scale: 1, duration: 1, ease: 'power2.out' }, '-=0.8')
        .fromTo('.hero-content', { x: '-6vw', opacity: 0 }, { x: 0, opacity: 1, duration: 1, ease: 'power3.out' }, '-=0.4')
        .fromTo('.hero-right', { x: '6vw', opacity: 0 }, { x: 0, opacity: 1, duration: 1, ease: 'power3.out' }, '-=0.6')
        .fromTo('.hero-cta', { y: 20, opacity: 0 }, { y: 0, opacity: 1, duration: 0.6, stagger: 0.12, ease: 'power2.out' }, '-=0.3')
        .fromTo('.hero-title', { y: 30, opacity: 0 }, { y: 0, opacity: 1, duration: 0.8, ease: 'power2.out' }, '-=0.5');

      gsap.utils.toArray('.section-content').forEach((section: any) => {
        gsap.fromTo(section, { opacity: 0, y: 40 }, {
          opacity: 1, y: 0, duration: 0.8, ease: 'power2.out',
          scrollTrigger: { trigger: section, start: 'top 88%', once: true }
        });
      });

      gsap.utils.toArray('.row-card').forEach((card: any, i: number) => {
        gsap.fromTo(card, { opacity: 0, y: 25, scale: 0.95 }, {
          opacity: 1, y: 0, scale: 1, duration: 0.5, delay: i * 0.05, ease: 'power2.out',
          scrollTrigger: { trigger: card, start: 'top 92%', once: true }
        });
      });
    }, heroRef);
    return () => ctx.revert();
  }, []);

  // Auto-advance hero slider
  useEffect(() => {
    if (heroSlides.length < 2) return;
    const interval = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % Math.min(heroSlides.length, 5));
    }, 6000);
    return () => clearInterval(interval);
  }, [heroSlides.length]);

  const formatDuration = (seconds: number) => {
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    return h > 0 ? `${h}h ${m}m` : `${m}m`;
  };

  // ── Render ─────────────────────────────────────────────────
  return (
    <div className="relative" ref={heroRef}>

      {/* ── HERO SECTION ── */}
      <section className="relative w-full h-[70vh] md:h-[80vh] overflow-hidden">
        {featured.length > 0 && (
          <>
            <div className="absolute inset-0 z-0">
              <img
                src={featured[0].backdrop}
                alt={featured[0].title}
                className="w-full h-full object-cover brightness-[0.4]"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[var(--bg-base)] via-transparent to-transparent" />
              <div className="absolute inset-0 bg-gradient-to-r from-[var(--bg-base)]/80 via-transparent to-transparent hidden md:block" />
            </div>

            <div className="absolute bottom-0 left-0 right-0 z-10 p-6 md:p-16 lg:px-24">
              <div className="max-w-3xl">
                <div className="flex items-center gap-3 mb-4 flex-wrap">
                  <span className="rating-badge text-xs md:text-sm">
                    <Star className="w-3.5 h-3.5 md:w-4 md:h-4 fill-current" />
                    {featured[0].tmdbRating}
                  </span>
                  <span className="text-white/60 text-xs md:text-sm font-bold uppercase tracking-widest">{featured[0].releaseYear}</span>
                  <span className="px-2 py-0.5 rounded bg-[var(--accent)] text-white text-[10px] font-black uppercase tracking-widest">Premium</span>
                </div>
                <h1 className="text-4xl md:text-6xl lg:text-8xl font-black text-white uppercase mb-4 md:mb-6 leading-[1] md:leading-[0.9] tracking-tighter italic" style={{ fontFamily: 'Sora, sans-serif' }}>
                  {featured[0].title}
                </h1>
                <p className="text-white/60 text-xs md:text-lg mb-6 md:mb-8 line-clamp-2 md:line-clamp-3 max-w-2xl font-medium leading-relaxed">
                  {featured[0].description}
                </p>
                <div className="flex flex-col md:flex-row items-stretch md:items-center gap-4">
                  <Link
                    to={`/content/${featured[0].id}`}
                    className="flex-1 md:flex-none flex items-center justify-center gap-3 px-8 md:px-12 py-3.5 md:py-4 rounded-full bg-[var(--accent)] hover:bg-[var(--accent-hover)] text-white font-black text-xs md:text-sm uppercase tracking-widest transition-all shadow-[0_0_40px_rgba(232,68,44,0.3)] active:scale-95"
                  >
                    <Play className="w-4 h-4 md:w-5 md:h-5 fill-current" /> Play Now
                  </Link>
                  <button className="hidden md:flex p-4 rounded-full bg-white/5 border border-white/10 hover:bg-white/10 transition-all text-white active:scale-90">
                    <Plus className="w-6 h-6" />
                  </button>
                </div>
              </div>
            </div>
          </>
        )}
      </section>

      {/* ── GENRE TABS ── */}
      <section className="section-content py-6 md:py-10 px-4 md:px-6 lg:px-16">
        <div className="scroll-row no-scrollbar">
          {GENRES.map((genre) => (
            <button
              key={genre}
              onClick={() => setActiveGenre(genre)}
              className={`genre-tag text-[10px] md:text-xs ${activeGenre === genre ? 'active' : ''}`}
            >
              {genre}
            </button>
          ))}
        </div>
      </section>

      {/* ── TRENDING ── */}
      <section className="section-content py-8 md:py-12 px-6 lg:px-16">
        <div className="flex items-center justify-between mb-6 md:mb-8">
          <h2 className="section-title text-xl md:text-2xl">Trending Now</h2>
          <Link to="/browse?sort=trending" className="text-[var(--text-secondary)] hover:text-white text-xs md:text-sm flex items-center gap-1.5 transition-colors group">
            View All <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </Link>
        </div>
        <div className="scroll-row no-scrollbar">
          {trending.length === 0
            ? Array.from({ length: 8 }).map((_, i) => (
                <div key={i} className="w-[140px] md:w-[180px] aspect-[2/3] skeleton rounded-2xl flex-shrink-0" />
              ))
            : trending.map((content, idx) => (
                <div key={content.id} className="row-card w-[140px] md:w-[180px]">
                  <ContentCard content={content} />
                </div>
              ))
          }
        </div>
      </section>

      {/* ── TOP 10 MOVIES TODAY ── */}
      <section className="section-content py-12 px-6 lg:px-16 overflow-visible">
        <div className="flex flex-col md:flex-row md:items-center justify-between mb-8 md:mb-12 gap-6">
          <div className="flex items-baseline gap-3 md:gap-5">
            <h2 className="text-5xl md:text-8xl font-black text-outline-accent tracking-tighter uppercase italic" 
                style={{ fontFamily: 'Sora, sans-serif' }}>
              TOP 10
            </h2>
            <div className="flex flex-col leading-none">
              <span className="text-white text-sm md:text-lg font-black tracking-[0.25em] uppercase">Movies</span>
              <span className="text-white text-sm md:text-lg font-black tracking-[0.25em] uppercase opacity-40">Today</span>
            </div>
          </div>
          
          <div className="relative group self-start md:self-auto">
            <button className="flex items-center gap-4 px-6 md:px-8 py-2.5 md:py-3 rounded-full border border-white/10 hover:border-[var(--accent)]/50 bg-white/5 backdrop-blur-xl transition-all group/btn">
              <span className="text-white text-xs md:text-sm font-bold tracking-wide">Movies</span>
              <ChevronRight className="w-4 h-4 rotate-90 text-white group-hover/btn:text-[var(--accent)] transition-colors" />
            </button>
          </div>
        </div>

        <div className="scroll-row items-end gap-0 pb-8 px-4 -mx-4 no-scrollbar">
          {(trending.length > 0 ? trending.slice(0, 10) : Array.from({ length: 10 })).map((content, idx) => (
            <div key={content?.id || idx} className="row-card relative flex-shrink-0 group" style={{ width: '200px', md: '240px', height: '280px', md: '340px' }}>
              {/* Number background */}
              <div className="absolute left-[-5px] md:left-[-10px] bottom-[-20px] md:bottom-[-30px] z-0 select-none pointer-events-none">
                <span className="text-[160px] md:text-[220px] font-black text-outline-accent leading-none italic opacity-60 group-hover:opacity-100 transition-all duration-500 scale-95 group-hover:scale-100" 
                      style={{ 
                        fontFamily: 'Sora, sans-serif'
                      }}>
                  {idx + 1}
                </span>
              </div>
              
              {/* Poster card */}
              <div className="relative z-10 w-[130px] md:w-[190px] ml-10 md:ml-12 transition-all duration-500 group-hover:scale-105 group-hover:translate-y-[-20px] group-hover:translate-x-2">
                {content ? (
                  <ContentCard content={content} />
                ) : (
                  <div className="aspect-[2/3] skeleton rounded-2xl" />
                )}
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* ── FEATURED / EDITOR'S CHOICE ── */}
      {/* ── EDITOR'S CHOICE ── */}
      {featured[0] && (
        <section className="section-content py-8 md:py-12 px-6 lg:px-16">
          <div className="flex items-center justify-between mb-6 md:mb-8">
            <h2 className="section-title text-xl md:text-2xl">Editor's Choice</h2>
            <Link to="/browse?sort=featured" className="text-[var(--text-secondary)] hover:text-white text-xs md:text-sm flex items-center gap-1.5 transition-colors group">
              View All <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </Link>
          </div>
          <Link to={`/content/${featured[0].id}`} className="group relative block w-full aspect-[16/9] md:aspect-[21/9] rounded-2xl overflow-hidden shadow-2xl">
            <img
              src={featured[0].backdrop}
              alt={featured[0].title}
              className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-[var(--bg-base)] via-[rgba(6,8,10,0.5)] to-transparent" />
            <div className="absolute bottom-0 left-0 right-0 p-6 md:p-8 lg:p-12 bg-gradient-to-t from-black/90 via-black/40 to-transparent">
              <span className="inline-block px-2.5 py-1 glass-accent rounded-full text-[var(--accent)] text-[10px] md:text-xs font-black uppercase tracking-widest mb-3">Editor's Pick</span>
              <h3 className="text-xl md:text-2xl lg:text-4xl font-black text-white mb-2 md:mb-3 uppercase tracking-tight" style={{ fontFamily: 'Sora, sans-serif' }}>
                {featured[0].title}
              </h3>
              <p className="text-white/60 text-xs md:text-base max-w-xl line-clamp-2 md:line-clamp-3 font-medium">{featured[0].description}</p>
            </div>
          </Link>
        </section>
      )}

      {/* ── POPULAR MOVIES ── */}
      <section className="section-content py-8 md:py-12 px-6 lg:px-16">
        <div className="flex items-center justify-between mb-6 md:mb-8">
          <h2 className="section-title text-xl md:text-2xl">Popular Movies</h2>
          <Link to="/browse?type=movie" className="text-[var(--text-secondary)] hover:text-white text-xs md:text-sm flex items-center gap-1.5 transition-colors group">
            View All <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </Link>
        </div>
        <div className="scroll-row no-scrollbar">
          {popularMovies.length === 0
            ? Array.from({ length: 8 }).map((_, i) => (
                <div key={i} className="w-[140px] md:w-[180px] aspect-[2/3] skeleton rounded-2xl flex-shrink-0" />
              ))
            : popularMovies.map((content, idx) => (
                <div key={content.id} className="row-card w-[140px] md:w-[180px]">
                  <ContentCard content={content} />
                </div>
              ))
          }
        </div>
      </section>

      {/* ── NOW PLAYING ── */}
      <section className="section-content py-8 md:py-12 px-6 lg:px-16">
        <div className="flex items-center justify-between mb-6 md:mb-8">
          <h2 className="section-title text-xl md:text-2xl">Now Playing</h2>
          <Link to="/browse?sort=now_playing" className="text-[var(--text-secondary)] hover:text-white text-xs md:text-sm flex items-center gap-1.5 transition-colors group">
            View All <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </Link>
        </div>
        <div className="scroll-row no-scrollbar">
          {nowPlaying.length === 0
            ? Array.from({ length: 8 }).map((_, i) => (
                <div key={i} className="w-[140px] md:w-[180px] aspect-[2/3] skeleton rounded-2xl flex-shrink-0" />
              ))
            : nowPlaying.map((content, idx) => (
                <div key={content.id} className="row-card w-[140px] md:w-[180px]">
                  <ContentCard content={content} />
                </div>
              ))
          }
        </div>
      </section>

      {/* ── TV SERIES ── */}
      <section className="section-content py-8 md:py-12 px-6 lg:px-16">
        <div className="flex items-center justify-between mb-6 md:mb-8">
          <h2 className="section-title text-xl md:text-2xl">TV Series</h2>
          <Link to="/browse?type=series" className="text-[var(--text-secondary)] hover:text-white text-xs md:text-sm flex items-center gap-1.5 transition-colors group">
            View All <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </Link>
        </div>
        <div className="scroll-row no-scrollbar">
          {popularSeries.length === 0
            ? Array.from({ length: 8 }).map((_, i) => (
                <div key={i} className="w-[140px] md:w-[180px] aspect-[2/3] skeleton rounded-2xl flex-shrink-0" />
              ))
            : popularSeries.map((content, idx) => (
                <div key={content.id} className="row-card w-[140px] md:w-[180px]">
                  <ContentCard content={content} />
                </div>
              ))
          }
        </div>
      </section>

      {/* ── BOTTOM FEATURED MOVIE (The Mummy Style) ── */}
      <section className="section-content py-12 md:py-20 px-4 md:px-6 lg:px-16">
        <div className="relative w-full max-w-7xl mx-auto min-h-[420px] md:min-h-[480px] rounded-[32px] md:rounded-[48px] overflow-hidden bg-[#0D1014] shadow-[0_0_80px_rgba(0,0,0,0.8)] group">
          {/* Background with advanced vignette */}
          <div className="absolute inset-0 z-0">
            <img 
              src="https://images.unsplash.com/photo-1509248961158-e54f6934749c?w=1920&h=1080&fit=crop" 
              alt="Background" 
              className="w-full h-full object-cover opacity-30 transition-transform duration-1000 group-hover:scale-110"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-[#06080A] via-[#06080A]/80 to-transparent" />
            <div className="absolute inset-0 bg-gradient-to-t from-[#06080A] via-transparent to-[#06080A]/40" />
            
            {/* Ambient glows */}
            <div className="absolute top-[-10%] right-[-10%] w-[50%] h-[50%] bg-[var(--accent)]/10 blur-[120px] rounded-full" />
            <div className="absolute bottom-[-10%] left-[20%] w-[40%] h-[40%] bg-[var(--accent)]/5 blur-[100px] rounded-full" />
          </div>

          <div className="relative z-10 h-full flex flex-col md:flex-row items-center p-8 md:p-10 lg:p-16 gap-8 md:gap-12 text-center md:text-left">
            {/* Poster on the left */}
            <div className="hidden md:block w-56 md:w-64 h-80 md:h-96 rounded-3xl overflow-hidden shadow-[0_20px_50px_rgba(0,0,0,0.6)] flex-shrink-0 transition-all duration-700 group-hover:scale-[1.02] group-hover:-rotate-1">
              <div className="relative w-full h-full">
                <img 
                  src="https://images.unsplash.com/photo-1536440136628-849c177e76a1?w=500&h=750&fit=crop" 
                  alt="Poster" 
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
                <div className="absolute bottom-6 left-6 right-6">
                   <p className="text-[10px] font-black text-white/60 uppercase tracking-[0.3em] mb-1 italic">LEE CRONIN'S</p>
                   <h4 className="text-lg font-black text-white uppercase tracking-tighter leading-none">THE MUMMY</h4>
                </div>
              </div>
            </div>

            {/* Content info */}
            <div className="flex-1 max-w-2xl">
              <p className="text-white/60 text-[10px] md:text-sm font-black uppercase tracking-[0.5em] mb-4 italic" style={{ fontFamily: 'Sora, sans-serif' }}>
                LEE CRONIN'S
              </p>
              <h2 className="text-4xl md:text-5xl lg:text-7xl font-black text-white uppercase tracking-tight mb-6 md:mb-8 leading-[1] md:leading-[0.9]" style={{ fontFamily: 'Sora, sans-serif' }}>
                THE MUMMY
              </h2>

              <div className="flex items-center justify-center md:justify-start gap-4 md:gap-5 mb-6 md:mb-8 flex-wrap">
                <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-white/5 backdrop-blur-md border border-white/10">
                  <Star className="w-3.5 h-3.5 md:w-4 md:h-4 text-[var(--accent)] fill-[var(--accent)]" />
                  <span className="text-white text-xs md:text-sm font-black">8.6</span>
                </div>
                <span className="text-white/50 text-xs md:text-sm font-bold tracking-wide">2h 14m</span>
                <span className="px-3 md:px-4 py-1.5 rounded-full bg-white/5 border border-white/10 text-white/70 text-[10px] md:text-xs font-black uppercase tracking-widest">Horror</span>
              </div>

              <p className="text-white/50 text-sm md:text-base lg:text-lg leading-relaxed mb-8 md:mb-10 line-clamp-3 md:line-clamp-none font-medium">
                The young daughter of a journalist disappears into the desert without a trace—eight years later, the broken family is shocked when she is returned to them, as what should be a joyful reunion turns into a living...
              </p>

              <div className="flex flex-col md:flex-row items-stretch md:items-center gap-4 md:gap-5">
                <button className="flex-1 md:flex-none px-10 md:px-14 py-3.5 md:py-4 rounded-2xl bg-[var(--accent)] hover:bg-[var(--accent-hover)] text-white font-black text-xs md:text-sm uppercase tracking-widest transition-all hover:shadow-[0_0_30px_rgba(232,68,44,0.3)] active:scale-95">
                  Play Now
                </button>
                <button className="flex-1 md:flex-none px-10 md:px-14 py-3.5 md:py-4 rounded-2xl bg-white/5 hover:bg-white/10 text-white font-black text-xs md:text-sm uppercase tracking-widest backdrop-blur-xl border border-white/10 transition-all active:scale-95">
                  Details
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ── CTA BANNER ── */}
      <section className="section-content py-12 md:py-20 px-6 lg:px-16">
        <div className="relative rounded-[32px] md:rounded-[48px] overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-br from-[var(--accent)]/20 via-[var(--accent-hover)]/10 to-[var(--bg-card)]" />
          <div className="absolute inset-0 backdrop-blur-xl" />
          <div className="relative p-10 md:p-12 lg:p-20 text-center">
            <h2 className="text-2xl md:text-3xl lg:text-5xl font-black text-white mb-5 uppercase tracking-tight italic" style={{ fontFamily: 'Sora, sans-serif' }}>
              Stream Unlimited. <span className="text-[var(--accent)]">Anytime.</span> Anywhere.
            </h2>
            <p className="text-white/60 text-sm md:text-lg mb-8 md:mb-10 max-w-2xl mx-auto leading-relaxed font-medium">
              Access thousands of movies, shows, live news, and songs.
            </p>
            <Link to="/pricing" className="inline-flex items-center gap-3 px-10 py-4 rounded-full bg-[var(--accent)] hover:bg-[var(--accent-hover)] text-white font-black text-sm uppercase tracking-widest transition-all shadow-[0_0_40px_rgba(232,68,44,0.3)] active:scale-95">
              Subscribe Now <ChevronRight className="w-5 h-5" />
            </Link>
          </div>
        </div>
      </section>

    </div>
  );
}
