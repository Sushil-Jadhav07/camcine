import { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Search, Filter, X, ChevronDown } from 'lucide-react';
import { useQuery } from '@tanstack/react-query';
import { tmdbService } from '@/services/tmdbService';
import { ContentCard } from '@/components/cards/ContentCard';
import { usePlayerStore } from '@/store';

const TYPE_TABS = ['All', 'Movies', 'Series'];
const SORT_OPTIONS = [
  { value: 'popular', label: 'Most Popular' },
  { value: 'top_rated', label: 'Highest Rated' },
  { value: 'trending', label: 'Trending' },
];

const GENRES = [
  { id: 28, name: 'Action' },
  { id: 12, name: 'Adventure' },
  { id: 16, name: 'Animation' },
  { id: 35, name: 'Comedy' },
  { id: 80, name: 'Crime' },
  { id: 99, name: 'Documentary' },
  { id: 18, name: 'Drama' },
  { id: 10751, name: 'Family' },
  { id: 14, name: 'Fantasy' },
  { id: 27, name: 'Horror' },
  { id: 10402, name: 'Music' },
  { id: 9648, name: 'Mystery' },
  { id: 10749, name: 'Romance' },
  { id: 878, name: 'Sci-Fi' },
  { id: 53, name: 'Thriller' },
];

export function BrowsePage() {
  const [searchParams, setSearchParams] = useSearchParams();
  const [activeType, setActiveType] = useState('All');
  const [selectedGenreId, setSelectedGenreId] = useState<number | null>(null);
  const [sortBy, setSortBy] = useState('popular');
  const [isFiltersOpen, setIsFiltersOpen] = useState(false);
  const { openPlayer } = usePlayerStore();

  useEffect(() => {
    const type = searchParams.get('type');
    const genre = searchParams.get('genre');
    const sort = searchParams.get('sort');
    if (type === 'movie') setActiveType('Movies');
    else if (type === 'series') setActiveType('Series');
    if (genre) {
      const g = GENRES.find(g => g.name.toLowerCase() === genre.toLowerCase());
      if (g) setSelectedGenreId(g.id);
    }
    if (sort) setSortBy(sort);
  }, [searchParams]);

  const { data: content, isLoading } = useQuery({
    queryKey: ['browse', activeType, selectedGenreId, sortBy],
    queryFn: async () => {
      if (sortBy === 'trending') return tmdbService.getTrending();
      
      if (activeType === 'Movies') {
        if (sortBy === 'top_rated') return tmdbService.getTopRated();
        return tmdbService.getPopularMovies();
      }
      
      if (activeType === 'Series') {
        return tmdbService.getPopularSeries();
      }

      return tmdbService.getTrending();
    },
  });

  return (
    <div className="min-h-screen py-10 md:py-12 px-6 lg:px-16 bg-[#06080A]">
      {/* Header & Tabs */}
      <div className="flex flex-col md:flex-row md:items-center justify-between mb-8 md:mb-12 gap-6">
        <div>
          <h1 className="text-2xl md:text-3xl font-black uppercase tracking-tight text-white" style={{ fontFamily: 'Sora, sans-serif' }}>
            {activeType === 'Series' ? 'TV Shows' : activeType === 'Movies' ? 'Popular Movies' : 'Discover'}
          </h1>
        </div>
        
        <div className="flex flex-wrap items-center gap-4">
          <div className="flex p-1 bg-white/5 rounded-xl border border-white/5">
            {['Popular', 'Top Rated'].map((tab) => (
              <button
                key={tab}
                onClick={() => setSortBy(tab === 'Popular' ? 'popular' : 'top_rated')}
                className={`px-4 md:px-6 py-2 rounded-lg text-[10px] md:text-xs font-black uppercase tracking-widest transition-all ${
                  (tab === 'Popular' ? sortBy === 'popular' : sortBy === 'top_rated')
                    ? 'bg-white/10 text-white shadow-lg'
                    : 'text-white/30 hover:text-white'
                }`}
              >
                {tab}
              </button>
            ))}
          </div>
          
          <button 
            onClick={() => setIsFiltersOpen(!isFiltersOpen)}
            className="flex items-center gap-2 px-4 py-2 rounded-xl bg-white/5 border border-white/5 text-white/40 hover:text-white transition-all text-[10px] md:text-xs font-black uppercase tracking-widest"
          >
            <Filter className="w-4 h-4" /> Filter
          </button>
        </div>
      </div>

      {isFiltersOpen && (
        <div className="bg-white/5 p-6 rounded-2xl border border-white/5 mb-8 md:mb-12 animate-in fade-in slide-in-from-top-4 duration-500">
          <div className="flex flex-col gap-6">
            <div className="flex flex-wrap gap-2">
              {TYPE_TABS.map((tab) => (
                <button
                  key={tab}
                  onClick={() => setActiveType(tab)}
                  className={`px-4 md:px-5 py-2 md:py-2.5 rounded-xl text-[10px] md:text-xs font-black uppercase tracking-widest transition-all ${
                    activeType === tab
                      ? 'bg-[var(--accent)] text-white'
                      : 'bg-white/5 text-white/40 hover:text-white'
                  }`}
                >
                  {tab}
                </button>
              ))}
            </div>
            
            <div className="h-px w-full bg-white/10" />

            <div className="flex gap-2 flex-wrap">
              {GENRES.map((genre) => (
                <button
                  key={genre.id}
                  onClick={() => setSelectedGenreId(selectedGenreId === genre.id ? null : genre.id)}
                  className={`px-3 md:px-4 py-1.5 md:py-2 rounded-lg text-[9px] md:text-[10px] font-black uppercase tracking-widest transition-all ${
                    selectedGenreId === genre.id
                      ? 'bg-white/20 text-white'
                      : 'bg-white/5 text-white/30 hover:text-white'
                  }`}
                >
                  {genre.name}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {isLoading ? (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4 md:gap-6">
          {Array.from({ length: 12 }).map((_, i) => (
            <div key={i} className="skeleton aspect-[2/3] rounded-2xl" />
          ))}
        </div>
      ) : content?.length === 0 ? (
        <div className="text-center py-20 md:py-24 glass-card rounded-3xl">
          <Search className="w-12 h-12 md:w-16 md:h-16 text-white/20 mx-auto mb-5" />
          <h3 className="text-lg md:text-xl font-black text-white mb-3 uppercase tracking-tight">No results found</h3>
          <p className="text-white/40 mb-7 text-sm">Try adjusting your filters or search terms</p>
          <button onClick={() => { setSelectedGenreId(null); setSortBy('popular'); setActiveType('All'); }} className="px-8 py-3 rounded-full bg-white/5 border border-white/10 text-white text-xs font-black uppercase tracking-widest hover:bg-white/10 transition-all">
            Clear All Filters
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4 md:gap-6">
          {content?.map((item) => (
            <div key={item.id} className="hover-lift">
              <ContentCard content={item} />
            </div>
          ))}
        </div>
      )}

      {content && content.length > 0 && (
        <div className="text-center mt-12 md:mt-16">
          <button className="px-10 py-4 rounded-full bg-white/5 border border-white/10 text-white text-xs font-black uppercase tracking-widest hover:bg-white/10 transition-all active:scale-95">
            Load More
          </button>
        </div>
      )}
    </div>
  );
}
