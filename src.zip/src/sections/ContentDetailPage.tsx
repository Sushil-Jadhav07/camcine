import { useState, useEffect, useMemo } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { Play, Plus, Check, Share2, Clock, Calendar, Star, Download, ChevronRight, Film, Tv, ArrowLeft, VolumeX, Volume2, Info, Heart, Bookmark } from 'lucide-react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { tmdbService } from '@/services/tmdbService';
import { ContentCard } from '@/components/cards/ContentCard';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { usePlayerStore, useAuthStore, useWatchlistStore } from '@/store';
import type { Series } from '@/types';
import YouTube from 'react-youtube';

export function ContentDetailPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const { openPlayer } = usePlayerStore();
  const { isAuthenticated } = useAuthStore();
  const { watchlist, addToWatchlist, removeFromWatchlist } = useWatchlistStore();
  
  const [selectedSeasonIdx, setSelectedSeasonIdx] = useState(0);
  const [expandedEpisode, setExpandedEpisode] = useState<string | null>(null);
  const [showTrailer, setShowTrailer] = useState(false);
  const [trailerMuted, setTrailerMuted] = useState(true);

  const contentType = id?.startsWith('movie') ? 'movie' : 'series';
  const tmdbId = id ? parseInt(id.split('-')[1]) : null;

  const { data: content, isLoading } = useQuery({
    queryKey: ['content', id],
    queryFn: () => contentType === 'movie' ? tmdbService.getMovieDetails(tmdbId!) : tmdbService.getSeriesDetails(tmdbId!),
    enabled: !!tmdbId,
  });

  const { data: similarContent } = useQuery({
    queryKey: ['similar', id],
    queryFn: () => contentType === 'movie' ? tmdbService.getSimilarMovies(tmdbId!) : tmdbService.getSimilarSeries(tmdbId!),
    enabled: !!tmdbId,
  });

  // Extract YouTube ID safely
  const videoId = useMemo(() => {
    if (!content?.trailer) return null;
    const regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|\&v=)([^#\&\?]*).*/;
    const match = content.trailer.match(regExp);
    return (match && match[2].length === 11) ? match[2] : null;
  }, [content?.trailer]);

  useEffect(() => {
    let timer: ReturnType<typeof setTimeout>;
    if (videoId) {
      // Delay trailer by 5 seconds
      timer = setTimeout(() => {
        setShowTrailer(true);
      }, 5000);
    }
    return () => {
      if (timer) clearTimeout(timer);
      setShowTrailer(false); // Reset on unmount or ID change
    };
  }, [videoId]);

  // Handle season episode fetching
  useEffect(() => {
    if (contentType === 'series' && content && tmdbId) {
      const season = content.seasons[selectedSeasonIdx];
      if (season && season.episodes.length === 0) {
        tmdbService.getSeasonDetails(tmdbId, season.number).then(episodes => {
          queryClient.setQueryData(['content', id], (oldData: any) => {
            if (!oldData) return oldData;
            const newData = { ...oldData };
            newData.seasons[selectedSeasonIdx].episodes = episodes;
            return newData;
          });
        });
      }
    }
  }, [selectedSeasonIdx, contentType, id, tmdbId, queryClient]);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-[var(--bg-base)] flex items-center justify-center">
        <div className="text-center">
          <div className="spinner mb-4" />
          <p className="text-white/70">Loading content...</p>
        </div>
      </div>
    );
  }

  if (!content) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center glass-card p-12 rounded-3xl">
          <h1 className="text-2xl text-white mb-3">Content not found</h1>
          <Link to="/browse" className="text-[var(--accent)] hover:underline">Browse all content</Link>
        </div>
      </div>
    );
  }

  const isInWatchlist = watchlist.some(item => item.id === content.id);
  const isSeries = content.type === 'series';
  const series = isSeries ? (content as Series) : null;

  const handleWatchlistToggle = () => {
    if (!isAuthenticated) return;
    if (isInWatchlist) removeFromWatchlist('user-1', content.id);
    else addToWatchlist('user-1', content.id);
  };

  const trailerOpts = {
    playerVars: {
      autoplay: 1,
      controls: 0,
      loop: 1,
      mute: trailerMuted ? 1 : 0,
      playlist: videoId, // Required for loop to work with single video
      modestbranding: 1,
      showinfo: 0,
      fs: 0,
      iv_load_policy: 3,
      rel: 0,
      disablekb: 1,
    },
  };

  return (
    <div className="min-h-screen bg-[var(--bg-base)] text-white">
      {/* ── HERO SECTION (Cinematic) ── */}
      <div className="relative w-full h-[85vh] overflow-hidden">
        {/* Backdrop / Trailer */}
        {showTrailer && videoId ? (
          <div className="absolute inset-0 z-0 scale-110 pointer-events-none">
            <YouTube
              videoId={videoId}
              opts={trailerOpts}
              className="w-full h-full"
              iframeClassName="w-full h-full object-cover"
              onEnd={(e) => e.target.playVideo()}
            />
            <div className="absolute inset-0 bg-black/40" />
          </div>
        ) : (
          <div className="absolute inset-0 z-0">
            <img src={content.backdrop} alt={content.title} className="w-full h-full object-cover brightness-75" />
          </div>
        )}

        {/* Gradient Overlays */}
        <div className="absolute inset-0 z-10 bg-gradient-to-t from-[var(--bg-base)] via-transparent to-transparent" />
        <div className="absolute inset-0 z-10 bg-gradient-to-r from-[var(--bg-base)]/80 via-transparent to-transparent" />

        {/* Hero Content */}
        <div className="absolute inset-0 z-20 flex items-center px-6 md:px-8 lg:px-20">
          <div className="flex flex-col lg:flex-row gap-8 lg:gap-12 items-center lg:items-end max-w-7xl w-full pt-20 lg:pt-0">
            {/* Poster (Tilted) */}
            <div className="hidden lg:block w-64 h-[380px] rounded-2xl overflow-hidden shadow-[0_30px_60px_rgba(0,0,0,0.8)] border border-white/10 transform -rotate-3 transition-transform hover:rotate-0 duration-700">
              <img src={content.poster} alt={content.title} className="w-full h-full object-cover" />
            </div>

            {/* Info Area */}
            <div className="flex-1 pb-10 text-center lg:text-left">
              <div className="mb-6 md:mb-8">
                <div className="flex items-center justify-center lg:justify-start gap-4 mb-4">
                   <div className="bg-[var(--accent)] text-white text-[10px] font-black px-2 py-0.5 rounded uppercase tracking-widest">Premium</div>
                   <div className="flex items-center gap-1.5 text-yellow-500 font-bold text-sm">
                     <Star className="w-4 h-4 fill-current" />
                     {content.tmdbRating}
                   </div>
                </div>
                <h1 className="text-4xl md:text-6xl lg:text-8xl font-black text-white uppercase leading-[0.9] md:leading-[0.85] tracking-tighter mb-6 italic" style={{ fontFamily: 'Sora, sans-serif' }}>
                  {content.title}
                </h1>
                
                {/* Meta Row */}
                <div className="flex items-center justify-center lg:justify-start gap-4 md:gap-6 text-white/60 text-xs md:text-sm font-bold uppercase tracking-widest flex-wrap">
                  <span>{content.releaseYear}</span>
                  <span className="w-1.5 h-1.5 rounded-full bg-white/20 hidden md:block" />
                  <span>{content.duration ? `${Math.floor(content.duration / 60)} MIN.` : 'N/A'}</span>
                  <span className="w-1.5 h-1.5 rounded-full bg-white/20 hidden md:block" />
                  <span>{content.languages?.[0] || 'EN'}</span>
                </div>
              </div>

              {/* Description (Fades out when trailer starts) */}
              <div className={`transition-all duration-1000 ${showTrailer ? 'opacity-0 translate-y-4 pointer-events-none' : 'opacity-100 translate-y-0'}`}>
                <p className="text-white/70 text-base md:text-lg leading-relaxed max-w-2xl mb-8 md:mb-10 font-medium line-clamp-3 md:line-clamp-none mx-auto lg:mx-0">
                  {content.description}
                </p>
              </div>

              {/* Actions */}
              <div className="flex flex-col md:flex-row items-center justify-center lg:justify-start gap-4 md:gap-6">
                <button onClick={() => openPlayer(content)} className="w-full md:w-auto group flex items-center justify-center gap-4 px-8 md:px-10 py-3.5 md:py-4 rounded-full bg-[#D4FF00] hover:bg-[#e6ff4d] text-black font-black text-sm uppercase tracking-widest transition-all active:scale-95 shadow-[0_0_40px_rgba(212,255,0,0.3)]">
                  <Play className="w-5 h-5 md:w-6 md:h-6 fill-current group-hover:scale-110 transition-transform" />
                  Play Now!
                </button>
                <div className="flex items-center gap-4 w-full md:w-auto justify-center">
                  <button onClick={handleWatchlistToggle} className="flex-1 md:flex-none p-3.5 md:p-4 rounded-full bg-white/5 border border-white/10 hover:bg-white/10 transition-all text-white active:scale-90 flex items-center justify-center">
                    {isInWatchlist ? <Bookmark className="w-5 h-5 md:w-6 md:h-6 fill-[var(--accent)] text-[var(--accent)]" /> : <Heart className="w-5 h-5 md:w-6 md:h-6" />}
                  </button>
                  <button className="flex-1 md:flex-none p-3.5 md:p-4 rounded-full bg-white/5 border border-white/10 hover:bg-white/10 transition-all text-white active:scale-90 flex items-center justify-center">
                    <Share2 className="w-5 h-5 md:w-6 md:h-6" />
                  </button>
                </div>
               </div>
             </div>
           </div>
         </div>

        {/* Mute toggle for trailer */}
        {showTrailer && (
          <button 
            onClick={() => setTrailerMuted(!trailerMuted)}
            className="absolute bottom-6 md:bottom-10 right-6 md:right-10 z-30 p-3 md:p-4 rounded-full bg-black/40 backdrop-blur-md border border-white/10 hover:bg-black/60 transition-all active:scale-90"
          >
            {trailerMuted ? <VolumeX className="w-5 h-5 md:w-6 md:h-6 text-white" /> : <Volume2 className="w-5 h-5 md:w-6 md:h-6 text-white" />}
          </button>
        )}
      </div>

      {/* ── DETAILS & FILES SECTION ── */}
      <div className="px-6 md:px-8 lg:px-20 py-12 md:py-20">
        <div className="flex flex-col lg:flex-row gap-12 lg:gap-16">
          {/* Left Column: Metadata & Details */}
          <div className="flex-1 space-y-12 order-2 lg:order-1">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-x-12 gap-y-6 md:gap-y-8">
              <DetailItem label="Country" value={content.region || 'USA'} />
              <DetailItem label="Genre" value={content.genres?.join(', ') || 'N/A'} />
              <DetailItem label="Year" value={content.releaseYear?.toString()} />
              <DetailItem label="Director" value={content.crew?.find((c: any) => c.role === 'Director')?.name || 'N/A'} />
              <DetailItem label="Stars" value={content.cast?.slice(0, 3).map((c: any) => c.name).join(', ') || 'N/A'} />
              <DetailItem label="Tags" value={content.tags?.join(', ') || 'N/A'} />
            </div>

            {/* Recommendations Row */}
            <div className="pt-10 md:pt-12 border-t border-white/5">
              <h2 className="text-2xl md:text-3xl font-black text-white uppercase mb-8 md:mb-10 tracking-tight" style={{ fontFamily: 'Sora, sans-serif' }}>
                Recommendation
              </h2>
              <div className="scroll-row -mx-4 px-4 no-scrollbar">
                {similarContent?.map((item: any) => (
                  <div key={item.id} className="w-[160px] md:w-[220px]">
                    <ContentCard content={item} />
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Right Column: Movie Files (as seen in image) */}
          <div className="w-full lg:w-[380px] shrink-0 order-1 lg:order-2">
            <div className="bg-[#0D1014] rounded-2xl border border-white/5 overflow-hidden shadow-2xl sticky top-28">
              <div className="flex items-center gap-3 p-5 md:p-6 border-b border-white/5 bg-white/[0.02]">
                <Play className="w-4 h-4 md:w-5 md:h-5 text-[var(--accent)] fill-current" />
                <h3 className="font-black text-white uppercase tracking-widest text-xs md:text-sm">Movie Files</h3>
              </div>
              <div className="p-2 space-y-1">
                <button className="w-full flex items-center justify-between p-4 rounded-xl bg-[var(--accent)] text-white font-bold text-sm transition-all group">
                  <span>Movie 1</span>
                  <div className="w-2 h-2 rounded-full bg-white animate-pulse" />
                </button>
                {/* Placeholder for more files/qualities */}
                {[2, 3].map(i => (
                  <button key={i} className="w-full flex items-center justify-between p-4 rounded-xl hover:bg-white/5 text-white/40 hover:text-white font-bold text-sm transition-all group">
                    <span>Movie {i} (4K)</span>
                    <Download className="w-4 h-4 opacity-0 group-hover:opacity-100 transition-opacity" />
                  </button>
                ))}
              </div>
              <div className="p-5 md:p-6 bg-black/20 text-center">
                <p className="text-[9px] md:text-[10px] text-white/30 font-black uppercase tracking-[0.2em]">Select quality to stream or download</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function DetailItem({ label, value }: { label: string, value?: string }) {
  return (
    <div className="flex gap-4">
      <span className="w-24 shrink-0 text-white/30 text-sm font-black uppercase tracking-widest">{label}</span>
      <span className="flex-1 text-white/80 text-sm font-bold leading-relaxed">{value || 'N/A'}</span>
    </div>
  );
}
