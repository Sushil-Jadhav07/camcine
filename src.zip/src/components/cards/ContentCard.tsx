import { Link } from 'react-router-dom';
import { Play, Clock, Film, Tv, Star } from 'lucide-react';
import type { Content } from '@/types';
import { usePlayerStore } from '@/store';

interface ContentCardProps {
  content: Content;
  variant?: 'default' | 'large' | 'compact' | 'portrait';
  showBadge?: boolean;
  showPlayButton?: boolean;
  className?: string;
}

export function ContentCard({ content }: ContentCardProps) {
  const { openPlayer } = usePlayerStore();
  const isSeries = content.type === 'series';

  return (
    <Link 
      to={`/content/${content.id}`}
      className="group relative block w-full aspect-[2/3] rounded-2xl overflow-hidden bg-[var(--bg-elevated)] transition-all duration-500 hover:-translate-y-2 hover:shadow-[0_20px_40px_rgba(0,0,0,0.6)] border border-white/5 hover:border-[var(--accent)]/50"
    >
      <img
        src={content.poster}
        alt={content.title}
        className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
        loading="lazy"
      />
      
      {/* HD Badge */}
      <div className="absolute top-3 left-3 px-1.5 py-0.5 rounded bg-black/40 backdrop-blur-md border border-white/10 opacity-0 group-hover:opacity-100 transition-opacity">
        <span className="text-[10px] font-black text-white tracking-widest">HD</span>
      </div>

      <div className="absolute inset-0 bg-gradient-to-t from-black via-black/20 to-transparent opacity-60 group-hover:opacity-100 transition-opacity" />

      {/* Content Info */}
      <div className="absolute bottom-0 left-0 right-0 p-4 transform translate-y-2 group-hover:translate-y-0 transition-transform duration-500">
        <h3 className="text-white font-black text-sm leading-tight mb-1 truncate shadow-sm">
          {content.title}
        </h3>
        <div className="flex items-center justify-between">
          <span className="text-[10px] font-black text-white/40 uppercase tracking-widest">
            {isSeries ? `SS 1 · EP 1` : content.releaseYear}
          </span>
          <div className="flex items-center gap-1">
            <Star className="w-3 h-3 text-[var(--accent)] fill-current" />
            <span className="text-[10px] font-black text-white/60">{content.tmdbRating || '8.5'}</span>
          </div>
        </div>
      </div>

      {/* Play Overlay */}
      <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all duration-500 transform scale-90 group-hover:scale-100">
        <div className="p-4 rounded-full bg-[var(--accent)] shadow-2xl">
          <Play className="w-6 h-6 fill-current text-white" />
        </div>
      </div>
    </Link>
  );
}
