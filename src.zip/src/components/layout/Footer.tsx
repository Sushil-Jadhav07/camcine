import { Link } from 'react-router-dom';
import { Mail, Trash2, Globe, ShipWheel } from 'lucide-react';

export function Footer() {
  const footerSections = [
    {
      title: 'Authentication',
      links: [
        { name: 'Login', path: '/login' },
        { name: 'Favorites', path: '/favorites' },
        { name: 'Watchlist', path: '/watchlist' },
        { name: 'Rated Film', path: '/rated' },
      ],
    },
    {
      title: 'Explore',
      links: [
        { name: 'Movies', path: '/browse?type=movie' },
        { name: 'TV Shows', path: '/browse?type=series' },
        { name: 'Top Rated Movies', path: '/browse?sort=top_rated' },
        { name: 'Upcoming Movies', path: '/browse?sort=upcoming' },
        { name: 'Popular TV Shows', path: '/browse?sort=popular&type=series' },
      ],
    },
    {
      title: 'Search',
      links: [
        { name: 'Filters', path: '/search' },
        { name: 'Genres', path: '/search' },
        { name: 'Actors', path: '/search' },
        { name: 'Streaming', path: '/search' },
        { name: 'Vote Count', path: '/search' },
      ],
    },
  ];

  return (
    <footer className="bg-[var(--bg-base)] pt-20 pb-10 px-6 lg:px-16 border-t border-white/5">
      <div className="max-w-7xl mx-auto">
        {/* Logo Section */}
        <div className="flex flex-col items-center mb-16">
          <div className="relative w-24 h-24 mb-4 flex items-center justify-center">
             <div className="absolute inset-0 bg-white/5 rounded-full blur-2xl" />
             <ShipWheel className="w-20 h-20 text-white/80 relative z-10" strokeWidth={1.5} />
             <div className="absolute inset-0 flex items-center justify-center z-20">
               <span className="text-[10px] font-black text-white bg-black px-1.5 py-0.5 rounded border border-white/20">COS</span>
             </div>
          </div>
          <h2 className="text-3xl font-bold text-white tracking-tight" style={{ fontFamily: 'Sora, sans-serif' }}>
            CorsFlix
          </h2>
        </div>

        {/* Links Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 lg:gap-8">
          {footerSections.map((section) => (
            <div key={section.title}>
              <h3 className="text-white font-bold text-lg mb-6 uppercase tracking-wider" style={{ fontFamily: 'Sora, sans-serif' }}>
                {section.title}
              </h3>
              <ul className="space-y-3">
                {section.links.map((link) => (
                  <li key={link.name}>
                    <Link to={link.path} className="text-white/50 hover:text-white transition-colors text-[15px]">
                      {link.name}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}

          {/* Get in Touch Section */}
          <div>
            <h3 className="text-white font-bold text-lg mb-6 uppercase tracking-wider" style={{ fontFamily: 'Sora, sans-serif' }}>
              Get in Touch
            </h3>
            <p className="text-white/50 text-[15px] leading-relaxed mb-6">
              Stay connected with us to discover more stories about new movies and explore more with us
            </p>
            <div className="flex items-center gap-4">
              <a href="#" className="w-10 h-10 rounded-full bg-[var(--accent)]/10 flex items-center justify-center text-[var(--accent)] hover:bg-[var(--accent)]/20 transition-all">
                <Globe className="w-5 h-5" />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-[var(--accent)]/10 flex items-center justify-center text-[var(--accent)] hover:bg-[var(--accent)]/20 transition-all">
                <Mail className="w-5 h-5" />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-[var(--accent)]/10 flex items-center justify-center text-[var(--accent)] hover:bg-[var(--accent)]/20 transition-all">
                <Trash2 className="w-5 h-5" />
              </a>
            </div>
          </div>
        </div>

        {/* Bottom copyright */}
        <div className="mt-20 pt-8 border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-4 text-white/30 text-xs">
          <p>© 2026 CorsFlix. All rights reserved.</p>
          <div className="flex gap-8">
            <Link to="/privacy" className="hover:text-white transition-colors">Privacy Policy</Link>
            <Link to="/terms" className="hover:text-white transition-colors">Terms of Service</Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
